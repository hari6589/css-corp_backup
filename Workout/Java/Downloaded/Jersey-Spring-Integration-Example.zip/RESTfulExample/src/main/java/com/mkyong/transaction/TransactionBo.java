package com.mkyong.transaction;
 
public interface TransactionBo{
 
	String save();
 
}