package com.mkyong.transaction.impl;

import com.mkyong.transaction.TransactionBo;

public class TransactionBoImpl implements TransactionBo {

	public String save() {

		return "Jersey + Spring example";

	}

}