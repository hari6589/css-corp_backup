/** Automatically generated file. DO NOT MODIFY */
package com.tatatmi.e_contact;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}