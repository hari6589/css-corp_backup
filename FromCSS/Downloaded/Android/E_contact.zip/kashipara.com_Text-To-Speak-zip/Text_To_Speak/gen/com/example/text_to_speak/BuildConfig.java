/** Automatically generated file. DO NOT MODIFY */
package com.example.text_to_speak;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}