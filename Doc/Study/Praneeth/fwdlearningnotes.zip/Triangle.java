package algorithams;

import java.util.Scanner;

/*
 *  1
 *  22
 *  333
 */
public class Triangle {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int row =sc.nextInt();
		
		for(int i=0;i<=row;i++){
			for(int j=0;j<=row-i;j++){
				System.out.print(" ");
			}
			for(int k=0;k<=i;k++){
				System.out.print("*"+ " ");
			}
			System.out.println();
		}
		sc.close();
	}
}
