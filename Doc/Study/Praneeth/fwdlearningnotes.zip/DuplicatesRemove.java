package algorithams;

import java.util.Scanner;

public class DuplicatesRemove {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
/*int [] i = new int[2];
 * tet
i.length*/
		String s = sc.next();
		char c = 0;
		for(int i=0;i<s.length();i++){
			c = Character.valueOf(s.charAt(i));
			if(s.charAt(i)==s.charAt(i+1)){
				
			}
		}
		System.out.println(c);
		
		
		
		
		
	}
}
